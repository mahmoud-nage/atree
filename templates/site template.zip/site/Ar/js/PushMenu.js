$(document).ready(function () {
  $('.main-header .nav-link[data-widget="pushmenu"]').click(function () {
    $('body').toggleClass("sidebar-collapse")
  })
})