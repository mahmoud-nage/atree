$(document).ready(function () {
  // $(".AddToWishlist").click(function () {
  //   $(this).find("i").toggleClass("font-weight-light .fa")
  // })
})